# Blog Section Implementation Guide

## Preview
Your blog section preview is live at: **https://nxodlmvkugofw.ok.kimi.link**

---

## What Was Created

A stunning blog section with **floating scattered images** that animate around your title text - exactly like the video you shared. The effect includes:

- Multiple images scattered at different positions around the text
- Smooth floating/bobbing animation on each image
- Images hover and scale up when you mouse over them
- Parallax effect on the title text following mouse movement
- Dark theme with gradient overlays for depth

---

## How to Use in Your Project

### Step 1: Copy the Component

Copy the file `src/sections/BlogSection.tsx` from this project to your portfolio's `src/sections/` folder.

### Step 2: Install Dependencies

Make sure you have framer-motion installed:

```bash
npm install framer-motion
```

### Step 3: Replace Your Current Blog Section

In your main App.tsx or wherever your blog section is, replace it with:

```tsx
import BlogSection from './sections/BlogSection';

// Replace your existing blog section with:
<BlogSection
  title="BLOG"
  subtitle="Creative Insights"
  description="Your custom description here"
/>
```

### Step 4: Add Your Images

**Option A: Simple Image Replacement (Recommended)**

1. Add your images to your project's `public/blog_images/` folder
2. Update the image paths in the component (see below)

**Option B: Custom Images Array**

Pass your own images array as a prop:

```tsx
const myBlogImages = [
  {
    id: 1,
    src: '/path/to/your/image1.jpg',
    alt: 'Description',
    x: 15,        // Position: 0-100% from left
    y: 20,        // Position: 0-100% from top
    width: 200,   // Image width in pixels
    height: 150,  // Image height in pixels
    rotation: -8, // Rotation in degrees
    zIndex: 3,    // Layer order
    floatSpeed: 2,      // Animation speed
    floatAmplitude: 8,  // Animation height
  },
  // Add more images...
];

<BlogSection
  title="BLOG"
  customImages={myBlogImages}
/>
```

---

## Customization Options

### Props Available

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `title` | string | "BLOG" | Main title text |
| `subtitle` | string | undefined | Subtitle below title |
| `description` | string | "Exploring creativity..." | Bottom description |
| `customImages` | BlogImage[] | defaultBlogImages | Array of image objects |
| `backgroundColor` | string | "#0a0a0a" | Section background color |
| `textColor` | string | "#ffffff" | Text color |

### Image Object Properties

| Property | Type | Description |
|----------|------|-------------|
| `id` | number | Unique identifier |
| `src` | string | Image path/URL |
| `alt` | string | Alt text for accessibility |
| `x` | number | Horizontal position (0-100%) |
| `y` | number | Vertical position (0-100%) |
| `width` | number | Image width in pixels |
| `height` | number | Image height in pixels |
| `rotation` | number | Rotation angle in degrees |
| `zIndex` | number | Layer stacking order |
| `floatSpeed` | number | Animation speed (1-5 recommended) |
| `floatAmplitude` | number | Animation height in pixels |

---

## Image Positioning Tips

- **x: 0-50** = Left side of screen
- **x: 50-100** = Right side of screen
- **y: 0-50** = Top half of screen
- **y: 50-100** = Bottom half of screen
- Keep images away from center (x: 40-60, y: 40-60) where text appears
- Use different zIndex values to create depth
- Vary rotation angles for a more organic feel

---

## Files Included

```
/mnt/okcomputer/output/
├── app/
│   ├── src/
│   │   └── sections/
│   │       └── BlogSection.tsx    # Main component
│   └── public/
│       └── blog_images/           # Sample images
├── blog_images/                   # Copy of sample images
└── BLOG_SECTION_GUIDE.md         # This guide
```

---

## Need Help?

The component is fully typed with TypeScript and includes comments throughout. If you need to modify the animation behavior, look for the `framer-motion` components in the code.
