import { useEffect, useRef, useState } from 'react';
import { motion, useAnimationFrame, useMotionValue } from 'framer-motion';

interface BlogImage {
  id: number;
  src: string;
  alt: string;
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  zIndex: number;
  floatSpeed: number;
  floatAmplitude: number;
}

// Default blog images - REPLACE THESE WITH YOUR OWN IMAGES
const defaultBlogImages: BlogImage[] = [
  {
    id: 1,
    src: '/blog_images/branding.jpg',
    alt: 'Branding Design',
    x: 15,
    y: 20,
    width: 200,
    height: 150,
    rotation: -8,
    zIndex: 3,
    floatSpeed: 2,
    floatAmplitude: 8,
  },
  {
    id: 2,
    src: '/blog_images/poster.jpg',
    alt: 'Graphic Design Poster',
    x: 70,
    y: 15,
    width: 180,
    height: 240,
    rotation: 5,
    zIndex: 4,
    floatSpeed: 2.5,
    floatAmplitude: 10,
  },
  {
    id: 3,
    src: '/blog_images/portrait.jpg',
    alt: 'Artistic Portrait',
    x: 25,
    y: 55,
    width: 160,
    height: 200,
    rotation: -3,
    zIndex: 2,
    floatSpeed: 1.8,
    floatAmplitude: 6,
  },
  {
    id: 4,
    src: '/blog_images/illustration.jpg',
    alt: 'Digital Illustration',
    x: 60,
    y: 50,
    width: 220,
    height: 160,
    rotation: 7,
    zIndex: 5,
    floatSpeed: 2.2,
    floatAmplitude: 9,
  },
  {
    id: 5,
    src: '/blog_images/abstract.jpg',
    alt: 'Abstract Art',
    x: 80,
    y: 65,
    width: 170,
    height: 130,
    rotation: -5,
    zIndex: 3,
    floatSpeed: 1.5,
    floatAmplitude: 7,
  },
  {
    id: 6,
    src: '/blog_images/packaging.png',
    alt: 'Product Packaging',
    x: 8,
    y: 70,
    width: 190,
    height: 140,
    rotation: 4,
    zIndex: 2,
    floatSpeed: 2.8,
    floatAmplitude: 11,
  },
  {
    id: 7,
    src: '/blog_images/colorful_abstract.jpg',
    alt: 'Colorful Abstract',
    x: 45,
    y: 25,
    width: 150,
    height: 200,
    rotation: -6,
    zIndex: 4,
    floatSpeed: 2,
    floatAmplitude: 8,
  },
  {
    id: 8,
    src: '/blog_images/identity.jpg',
    alt: 'Brand Identity',
    x: 75,
    y: 35,
    width: 200,
    height: 150,
    rotation: 3,
    zIndex: 3,
    floatSpeed: 1.7,
    floatAmplitude: 6,
  },
  {
    id: 9,
    src: '/blog_images/digital_art.jpg',
    alt: 'Digital Art',
    x: 35,
    y: 75,
    width: 180,
    height: 180,
    rotation: -4,
    zIndex: 5,
    floatSpeed: 2.3,
    floatAmplitude: 10,
  },
];

interface FloatingImageProps {
  image: BlogImage;
  index: number;
}

const FloatingImage = ({ image, index }: FloatingImageProps) => {
  const yOffset = useMotionValue(0);
  
  useAnimationFrame((t) => {
    const offset = Math.sin((t / 1000) * image.floatSpeed + index) * image.floatAmplitude;
    yOffset.set(offset);
  });

  return (
    <motion.div
      className="absolute cursor-pointer"
      style={{
        left: `${image.x}%`,
        top: `${image.y}%`,
        width: image.width,
        height: image.height,
        zIndex: image.zIndex,
        y: yOffset,
      }}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.15,
        ease: [0.25, 0.46, 0.45, 0.94]
      }}
      whileHover={{ 
        scale: 1.08, 
        zIndex: 100,
        transition: { duration: 0.3 }
      }}
    >
      <div
        className="w-full h-full overflow-hidden shadow-2xl"
        style={{
          transform: `rotate(${image.rotation}deg)`,
          borderRadius: '4px',
        }}
      >
        <img
          src={image.src}
          alt={image.alt}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
      </div>
    </motion.div>
  );
};

interface BlogSectionProps {
  title?: string;
  subtitle?: string;
  description?: string;
  customImages?: BlogImage[];
  backgroundColor?: string;
  textColor?: string;
}

const BlogSection = ({
  title = 'BLOG',
  subtitle,
  description = 'Exploring creativity through design, photography, and visual storytelling.',
  customImages,
  backgroundColor = '#0a0a0a',
  textColor = '#ffffff',
}: BlogSectionProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const images = customImages || defaultBlogImages;

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
        const y = (e.clientY - rect.top - rect.height / 2) / rect.height;
        setMousePosition({ x, y });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <section
      ref={containerRef}
      className="relative w-full min-h-screen overflow-hidden"
      style={{ backgroundColor }}
    >
      {/* Floating Images Layer */}
      <div className="absolute inset-0 pointer-events-none">
        {images.map((image, index) => (
          <div key={image.id} className="pointer-events-auto">
            <FloatingImage image={image} index={index} />
          </div>
        ))}
      </div>

      {/* Content Layer */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 sm:px-8">
        {/* Main Title */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          <h1
            className="text-[12vw] sm:text-[10vw] md:text-[8vw] font-bold tracking-tighter leading-none"
            style={{ 
              color: textColor,
              transform: `translate(${mousePosition.x * -15}px, ${mousePosition.y * -15}px)`,
              transition: 'transform 0.3s ease-out',
            }}
          >
            {title}
          </h1>
          
          {subtitle && (
            <motion.p
              className="mt-4 text-lg sm:text-xl md:text-2xl tracking-widest uppercase"
              style={{ color: textColor, opacity: 0.8 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.8 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              {subtitle}
            </motion.p>
          )}
        </motion.div>

        {/* Description */}
        <motion.div
          className="absolute bottom-12 left-0 right-0 text-center px-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          <p
            className="max-w-2xl mx-auto text-sm sm:text-base md:text-lg leading-relaxed"
            style={{ color: textColor, opacity: 0.7 }}
          >
            {description}
          </p>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          className="absolute bottom-4 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.5 }}
          transition={{ duration: 0.8, delay: 1.2 }}
        >
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
            <motion.div
              className="w-1 h-2 bg-white/60 rounded-full"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            />
          </div>
        </motion.div>
      </div>

      {/* Gradient Overlays for depth */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at center, transparent 0%, ${backgroundColor}80 100%)`,
        }}
      />
    </section>
  );
};

export default BlogSection;
export { defaultBlogImages };
export type { BlogImage, BlogSectionProps };
