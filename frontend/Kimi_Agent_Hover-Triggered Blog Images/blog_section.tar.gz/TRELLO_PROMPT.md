# Trello Integration Prompt

Copy and paste this into your Trello card or send to your developer:

---

## Trello Card Title
Implement New Blog Section with Floating Images Animation

---

## Trello Card Description

### Overview
Replace the current blog section with a new design featuring floating scattered images that animate around the title text.

### Preview
Live preview: https://nxodlmvkugofw.ok.kimi.link

### Implementation Steps

#### 1. Install Dependency
```bash
npm install framer-motion
```

#### 2. Add Component File
Create `src/sections/BlogSection.tsx` with the provided code.

#### 3. Replace Existing Blog Section
In the main App file, remove the current blog section and import:
```tsx
import BlogSection from './sections/BlogSection';

// Use:
<BlogSection
  title="BLOG"
  subtitle="Creative Insights"
  description="Exploring creativity through design, photography, and visual storytelling."
/>
```

#### 4. Add Images
- Create folder: `public/blog_images/`
- Add blog images to this folder
- Update image paths in BlogSection.tsx or pass customImages prop

### Customization Options
- **title**: Main heading text
- **subtitle**: Optional subheading
- **description**: Bottom description text
- **customImages**: Array of image objects with position, size, rotation
- **backgroundColor**: Section background (default: #0a0a0a)
- **textColor**: Text color (default: #ffffff)

### Image Object Format
```typescript
{
  id: number,
  src: string,        // Image path
  alt: string,        // Alt text
  x: number,          // Position 0-100%
  y: number,          // Position 0-100%
  width: number,      // Pixels
  height: number,     // Pixels
  rotation: number,   // Degrees
  zIndex: number,     // Layer order
  floatSpeed: number, // Animation speed
  floatAmplitude: number // Animation height
}
```

### Acceptance Criteria
- [ ] Blog section displays with floating images animation
- [ ] Images hover/scale on mouse over
- [ ] Title has parallax effect on mouse move
- [ ] Smooth floating animation on all images
- [ ] Responsive on mobile devices
- [ ] Old blog section completely removed

### Files to Receive
- BlogSection.tsx component file
- Sample images for testing

---

## Checklist for Developer

- [ ] Install framer-motion
- [ ] Copy BlogSection.tsx to src/sections/
- [ ] Add blog images to public/blog_images/
- [ ] Update App.tsx to use new BlogSection
- [ ] Remove old blog section code
- [ ] Test animations work correctly
- [ ] Test responsive behavior
- [ ] Deploy and verify

---

## Questions?

Refer to the full guide: BLOG_SECTION_GUIDE.md
